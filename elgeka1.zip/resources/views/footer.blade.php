
    	<!-- Footer -->
    	<div class="footer clearfix">
      		<div class="pull-left">&copy;<a href="http://kreasys.com">ELGEKA</a>  2015. </div>
    	</div>
    	<!-- /footer -->
  	</div>
  	<!-- /page content -->
</div>
<!-- /page container -->