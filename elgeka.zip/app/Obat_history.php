<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Obat_history extends Model {

	protected $table = 'obat_history';

	protected $fillable = [];

}
