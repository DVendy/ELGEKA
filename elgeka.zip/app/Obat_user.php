<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Obat_user extends Model {

	protected $table = 'obat_user';

	protected $fillable = [];

}
