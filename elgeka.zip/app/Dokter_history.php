<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Dokter_history extends Model {

	protected $table = 'dokter_history';

	protected $fillable = [];

}
