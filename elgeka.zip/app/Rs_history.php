<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Rs_history extends Model {

	protected $table = 'rs_history';

	protected $fillable = [];

}
