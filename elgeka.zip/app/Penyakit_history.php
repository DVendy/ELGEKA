<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Penyakit_history extends Model {

	protected $table = 'penyakit_history';

	protected $fillable = [];

}
