<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Asuransi_history extends Model {

	protected $table = 'asuransi_history';

	protected $fillable = [];

}
