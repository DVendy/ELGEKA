
    	<!-- Footer -->
    	<div class="footer clearfix">
      		<div class="pull-left">&copy;<a href="#">ELGEKA</a>  2015. </div>
    	</div>
    	<!-- /footer -->
  	</div>
  	<!-- /page content -->
</div>
<!-- /page container -->