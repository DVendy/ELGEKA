<div class="navbar navbar-inverse" role="navigation">
	<div class="container">
  <div class="navbar-header">
  	<a class="navbar-brand" href="{{ URL('/') }}"><img src="{{ URL::asset('images/logo_elgeka.png')}}" alt="Londinium" style="max-height:100%;"> ELGEKA</a>
  </div>
  </div>
</div>
<div class="poster">
	<div class="container">
		<div class="title">
			<h2>Himpunan Masyarakat Peduli ELGEKA
				<br>
			<span>LGK (Leukemia Granulositik Kronik) dan GIST (Kanker Saluran Pencernaan)</span>
			</h2>
		</div>
	</div>
</div>